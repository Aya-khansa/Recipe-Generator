<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = mysqli_connect('localhost', 'root', '', 'dataBase_name');


if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        echo "<script>alert('You must be logged in to add favorites.'); window.location.href='login.php';</script>";
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $recipe_id = isset($_POST['recipe_id']) ? intval($_POST['recipe_id']) : 0; 

    if ($recipe_id > 0) {
       
        $query = $conn->prepare("INSERT IGNORE INTO favoriteAll (user_id, recipe_id) VALUES (?, ?)");
        $query->bind_param("ii", $user_id, $recipe_id);

        if ($query->execute()) {
            echo "<script>alert('Recipe successfully added to favorites!'); window.location.href='favorites.php';</script>";
            exit();
        } else {
            echo "<script>alert('Failed to add to favorites. Please try again.'); window.location.href='website.php';</script>";
            exit();
        }
        $query->close();
    } else {
        echo "<script>alert('Invalid recipe selection.'); window.location.href='website.php';</script>";
        exit();
    }
}


mysqli_close($conn);
?>

