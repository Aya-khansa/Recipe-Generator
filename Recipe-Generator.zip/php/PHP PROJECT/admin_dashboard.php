<?php

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    
    header("Location: forms.php");
    exit();
}

$username = ''; 

include("selectDb.php");
$query = "SELECT username FROM login WHERE id = ?";
$stmt = $dbc->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();
?>

<html>
    <head>
        <title>Admin Dashboard</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #ffe6e6; 
                text-align: center;
                padding: 50px;
                margin: 0;
            }
            h1 {
                color: #ff5e62; 
            }
            p {
                color: #333;
            }
            .container {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
                gap: 15px;
                margin-top: 30px;
            }
            .button {
                padding: 15px 25px;
                font-size: 18px;
                cursor: pointer;
                background-color: #ff5e62; 
                color: white;
                border: none;
                border-radius: 5px;
                text-decoration: none;
                width: 200px;
                text-align: center;
            }
            .button:hover {
                background-color: #ff3b42;
            }
        </style>
    </head>
    <body>
        <h1>Welcome, Admin !</h1>
        <p>You can manage the website from here.</p>
        
        <div class="container">
            <a href="adminfav.php" class="button">Most Favorites</a>
            <a href="website.php" class="button">View Website</a>
            <a href="manage_users.php" class="button">View Users</a>
            <a href="introduction.php" class="button">Logout</a>
        </div>
    </body>
</html>
