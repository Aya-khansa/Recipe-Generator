<?php
include("selectdb.php");

$query = "INSERT INTO quantities (quantity_value, quantity_unit, recipe_id, ingredient_id)
VALUES (2, 'cups', 1, 14),    
       (1.5, 'cups', 1, 7),
       (3, 'cups', 1, 6),

       (0.5, 'cups', 2, 3),
       (2.5, 'cups', 2, 4),
       (1, 'cup', 2, 12),
       (1.25, 'cups', 2, 13),
       (0.75, 'cups', 2, 26),
       (1.5, 'cups', 2, 28),
       (2, 'cups', 2, 28),
       (3, 'cups', 2, 29),
       (2.5, 'cups', 2, 30),

       (1.75, 'cups', 3, 3),
       (2, 'cups', 3, 4),
       (1, 'cup', 3, 5),
       (2.25, 'cups', 3, 6),
       (0.5, 'cups', 3, 7),
       (3, 'cups', 3, 8),
       (1.5, 'cups', 3, 10),
       (1.25, 'cups', 3, 14),
       (2, 'cups', 3, 19),
       (0.75, 'cups', 3, 20),
       (1.5, 'cups', 3, 21),
       (2, 'cups', 3, 22)";

if (@mysqli_query($dbc, $query)) {
    print "<p>The information has been inserted successfully.</p>";
} else {
    print "<p>Error: Could not insert data. " . mysqli_error($dbc) . "</p>";
}

mysqli_close($dbc);
?>
