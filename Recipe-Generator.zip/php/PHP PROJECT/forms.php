<html>
<head>
    <title>LOGIN</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; 
            gap: 40px; 
        }


        .image-box {
            width: 500px;
            height: 500px;
            background-image: url("php project.jpg");
            background-size: cover;
            background-position: center;
            border-radius: 10px;
        }

        .form-box {
            width: 300px;
            padding: 30px;
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            text-align: center;
        }

        .form-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-box button {
            width: 100%;
            padding: 10px;
            background: #ff5e62;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .form-box button:hover {
            background: #ff3b3f;
        }


        .create-account {
            margin-top: 15px;
            font-size: 14px;
        }

        .create-account a {
            color: #ff5e62;
            text-decoration: none;
            font-weight: bold;
        }

        .create-account a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>



    <div class="container">

        <div class="image-box"></div>


        <div class="form-box">
            <h2>Register</h2>
            <form method="post" action="check.php">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" onClick='registerButton()'>Register</button>
            </form>
            
            <p class="create-account">Don't have an account? <a href="createAcc.php">Create one</a></p>
        </div>
    </div>

</body>
</html>
