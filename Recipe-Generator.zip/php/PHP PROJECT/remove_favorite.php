<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'dataBase_name');


if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['recipe_id']) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; 
    $recipe_id = intval($_POST['recipe_id']); 

    
    $stmt = $conn->prepare("DELETE FROM favoriteAll WHERE user_id = ? AND recipe_id = ?");
    $stmt->bind_param("ii", $user_id, $recipe_id);

    if ($stmt->execute()) {
        echo "<script>alert('Recipe removed from favorites!'); window.location.href='favorites.php';</script>";
    } else {
        echo "<script>alert('Failed to remove recipe.'); window.location.href='favorites.php';</script>";
    }

    $stmt->close();
} else {
    die("Invalid request.");
}
?>


