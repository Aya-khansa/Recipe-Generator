<html>
    <body>
<?php 
$dbc=@mysqli_connect('localhost','root','');

if($dbc)
{
    $dbname="dataBase_name";
    mysqli_select_db($dbc,$dbname)
    or die('<p> could not select the database</p>');
}
else{
    print'<p> could not connect to my sql server</p>';
}
?>
 </body>
</html>
