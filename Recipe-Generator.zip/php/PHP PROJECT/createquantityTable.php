<html>
    <body>

<?php

include("selectdb.php");

$query = "CREATE TABLE quantities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quantity_value DECIMAL(10,2) NOT NULL, 
    quantity_unit VARCHAR(20) NOT NULL,  
    recipe_id INT NOT NULL, 
    ingredient_id INT NOT NULL, 
    FOREIGN KEY (recipe_id) REFERENCES recipeAll(id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredient(ing_id) ON DELETE CASCADE
)";

if (@mysqli_query($dbc, $query)) {
    print "<p>The quantity table has been created successfully.</p>";
} else {
    print "<p>Error: Could not create the table. " . mysqli_error($dbc) . "</p>";
}

mysqli_close($dbc);
?>

</body>
</html>
