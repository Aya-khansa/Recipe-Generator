<?php
include("selectdb.php");


$query = 'INSERT INTO ingredient(ing_name)
VALUES ("Butter"),
("Egg"),
("sugar"),
("milk"),
("flour"),
("salt"),
("olive oil"),
("cheese"),
("baking powder"),
("yeast"),
("pasta"),
("oats"),
("Honey"),

("tomato"),
("garlic"),
("cucumber"),
("potato"),
("carrot"),
("mushroom"),
("corn"),
("olive"),
("onion"),
("lettuce"),
("lemon"),

("apple"),
("banana"),
("orange"),
("mango"),
("strawberry"),
("peach"),
("pomegranate"),
("lemon"),
("watermelon")';


if (@mysqli_query($dbc, $query)) {
    print '<p>The ingredient table has been created successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>