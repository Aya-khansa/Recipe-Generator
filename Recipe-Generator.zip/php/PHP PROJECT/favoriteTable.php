<html>
    <body>

<?php

include("selectDb.php");


$query= 'CREATE TABLE favoriteAll (
    user_id INT,
    recipe_id INT,
    FOREIGN KEY (user_id) REFERENCES login(id),
    FOREIGN KEY (recipe_id) REFERENCES recipeAll(id),
    PRIMARY KEY (user_id, recipe_id)
)';

if (@mysqli_query($dbc, $query)) {
    print '<p>The favorites table has been created successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>

</body>
</html>