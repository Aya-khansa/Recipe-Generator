<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: forms.php");
    exit();
}


include("selectDb.php");


$query = "SELECT id, username, role FROM login";
$stmt = $dbc->prepare($query);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($user_id, $username, $role);


$user_count_query = "SELECT COUNT(*) FROM login";
$count_result = $dbc->query($user_count_query);
$count_row = $count_result->fetch_row();
$user_count = $count_row[0];
?>

<html>
    <head>
        <title>Manage Users</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #ffe6e6;
                text-align: center;
                padding: 50px;
                margin: 0;
            }
            h1 {
                color: #ff5e62;
            }
            table {
                width: 80%;
                margin: 20px auto;
                border-collapse: collapse;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            th, td {
                padding: 10px;
                text-align: left;
                border: 1px solid #ddd;
            }
            th {
                background-color: #ff5e62;
                color: white;
            }
            tr:nth-child(even) {
                background-color: #f2f2f2;
            }
            .button {
                padding: 10px 20px;
                font-size: 16px;
                cursor: pointer;
                background-color: #ff5e62;
                color: white;
                border: none;
                border-radius: 5px;
                text-decoration: none;
            }
            .button:hover {
                background-color: #ff3b42;
            }
        </style>
    </head>
    <body>
        <h1>Manage Users</h1>
        <p>Total Users: <?php echo $user_count; ?></p>
        
    
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                <?php
          
                while ($stmt->fetch()):
                ?>
                    <tr>
                        <td><?php echo $user_id; ?></td>
                        <td><?php echo htmlspecialchars($username); ?></td>
                        <td><?php echo htmlspecialchars($role); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <br>
        <a href="admin_dashboard.php" class="button">Back to Dashboard</a>

        <?php
        $stmt->close();
        $dbc->close();
        ?>
    </body>
</html>

