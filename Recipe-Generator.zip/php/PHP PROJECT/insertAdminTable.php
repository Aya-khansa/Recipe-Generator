<?php
include("selectDb.php");

$username = 'admin'; 
$password = '000'; 

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$query = "INSERT INTO admin (username, password) VALUES (?, ?)";


$stmt = $dbc->prepare($query);
$stmt->bind_param("ss", $username, $hashed_password);

if ($stmt->execute()) {
    echo '<p>Admin has been added successfully to the admin table.</p>';
} else {
    echo '<p>Error: ' . $stmt->error . '</p>';
}

$stmt->close();
mysqli_close($dbc);
?>
