<html>
<head>
    <title>Recipe Generator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffe3e3;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .navbar {
            width: 100%;
            background-color: #ff5e62;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            font-size: 18px;
        }
        .navbar a:hover {
            background-color:rgb(250, 127, 129);
            border-radius: 5px;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 90vw;
            max-width: 1200px;
            height: 80vh;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }
        .header {
            font-size: 35px;
            font-weight: bold;
            color: #ff5e62;
            text-align: center;
            margin-bottom: 40px;
        }
        .generate-button {
            margin-top: 20px;
            padding: 15px 30px;
            font-size: 20px;
            background: #ff5e62;
            color: white;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .generate-button:hover {
            background: #e04b50;
        }
        .categories-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            width: 100%;
        }
        .category {
            flex: 1;
            min-width: 250px;
            background: #ffd6d6;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .category-title {
            font-size: 22px;
            font-weight: bold;
            color: #ff5e62;
            margin-bottom: 10px;
        }
        .ingredients {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
        }
        .form-check-input {
            margin-right: 10px;
        }
        .btn {
            display: inline-block;
            background: #ff5e62;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            margin-top: 15px;
            transition: 0.3s;
        }
        .btn:hover {
            background: #ffcce6;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div>
            <a href="introduction.php">Home</a>
        </div>
       
    </div>
    
    <form action="process.php" method="POST">
        <div class="container">
            <h1 class="header">Select Your Ingredients</h1>
            <div class="categories-container">
                
                <div class="category">
                    <div class="category-title">Pantry Essentials</div>
                    <div class="ingredients">
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Butter"> Butter</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Egg"> Egg</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Sugar"> Sugar</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Milk"> Milk</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Flour"> Flour</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Salt"> Salt</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Olive Oil"> Olive Oil</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Cheese"> Cheese</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Baking Powder"> Baking Powder</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Yeast"> Yeast</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Pasta"> Pasta</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Oats"> Oats</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Honey"> Honey</div>
                    </div>
                </div>

              
                <div class="category">
                    <div class="category-title">Vegetables</div>
                    <div class="ingredients">
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Tomato"> Tomato</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Garlic"> Garlic</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Cucumber"> Cucumber</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Potato"> Potato</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Carrot"> Carrot</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Mushroom"> Mushroom</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Corn"> Corn</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Olive"> Olive</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Onion"> Onion</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Lettuce"> Lettuce</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Lemon"> Lemon</div>
                    </div>
                </div>

               
                <div class="category">
                    <div class="category-title">Fruits</div>
                    <div class="ingredients">
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Apple"> Apple</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Banana"> Banana</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Orange"> Orange</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Mango"> Mango</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Strawberry"> Strawberry</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Peach"> Peach</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Pomegranate"> Pomegranate</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Lemon"> Lemon</div>
                        <div class="form-check"><input type="checkbox" class="form-check-input" name="ingredients[]" value="Watermelon"> Watermelon</div>
                        
                    </div>
                </div>
            </div>
            <a href="forms.php" class="btn">Generate Recipe</a>
        </div>
    </form>
</body>
</html>
