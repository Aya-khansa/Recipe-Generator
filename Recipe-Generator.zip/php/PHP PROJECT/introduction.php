<html>
<head>
    
    <title>Recipe Generator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #ffe3e3;
            color: #333;
        }
        .navbar {
            background-color:rgb(250, 127, 129); 
            padding: 15px;
            display: flex;
            justify-content: flex-start;
            gap: 20px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
            transition: background 0.3s;
        }
        .navbar a {
            color: white;
            padding: 10px 20px;
            font-size: 18px;
            transition: background 0.3s, border-radius 0.3s;
        }
      
        .navbar a:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }
        header {
            background:rgb(250, 127, 129);
            color: white;
            padding: 100px 20px;
            margin-top: 50px;
        }
        .header-content {
            max-width: 600px;
            margin: auto;
        }
        .btn {
            display: inline-block;
            background: white;
            color: #ff5e62;
            padding: 12px 25px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            margin-top: 15px;
            transition: 0.3s;
        }
        .btn:hover {
            background: #ffcce6;
        }
        #about, #features, #testimonials, #contact {
            padding: 50px 20px;
            background: white;
            margin: 40px auto;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            max-width: 800px;
        }
        .feature-list, .testimonial-list {
            text-align: left;
            max-width: 600px;
            margin: auto;
        }
        footer {
            background:rgb(250, 127, 129);
            color: white;
            padding: 15px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        /* Contact Form Styling */
        .contact-info {
            font-size: 18px;
            margin-bottom: 20px;
        }
        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .contact-form button {
            background-color: #d43f52;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        .contact-form button:hover {
            background-color: #ff5e62;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="introduction.php">Home</a>
        <a href="#about">About</a>
        <a href="#features">Features</a>
        <a href="#contact">Contact</a>
        <a href="forms.php">Sign Up/Log In</a>
    </nav>
    
    <header>
        <div class="header-content">
            <h1>Welcome to Recipe Generator</h1>
            <p>Your personal assistant for discovering delicious recipes!</p>
            <a href="test.php" class="btn">Explore Recipes</a>
        </div>
    </header>
    
    <section id="about">
    <h2>About Our Website</h2>
    <p>Have ingredients but not sure what to cook? Our Recipe Generator helps you find amazing recipes based on what you have in your kitchen!</p>
    <p>This website was created as a project by three students from the Lebanese University:</p>
    <ul>
        <li>Rita Abboud</li>
        <li>Jana Al Abed</li>
        <li>Aya Khansa</li>
    </ul>
</section>
    
    <section id="features">
        <h2>Features</h2>
        <ul class="feature-list">
            <li>✔ Easy ingredient-based recipe search</li>
            <li>✔ Personalized recipe recommendations</li>
            <li>✔ Save favorite recipes for later</li>
            <li>✔ Step-by-step cooking instructions</li>
        </ul>
    </section>
    
   
    
    <section id="contact">
        <h2>Contact Us</h2>
        <div class="contact-info">
            <p>For any questions or feedback, feel free to reach out to us:</p>
            <p>Email: <a href="mailto:support@recipegenerator.com">support@recipegenerator.com</a></p>
            <p>Phone: +1 234 567 890</p>
        </div>
        
    </section>
    
    <footer>
        <p>&copy; 2025 Recipe Generator. All rights reserved.</p>
    </footer>
</body>
</html>
