<html>
    <body>

<?php

include("selectDb.php");


$query = 'CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL

)';

if (@mysqli_query($dbc, $query)) {
    print '<p>The admin table has been created successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>

</body>
</html>