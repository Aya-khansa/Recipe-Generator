<?php
$host = 'localhost';
$db = 'dataBase_name';
$user = 'root'; 
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


$selected_ingredients = isset($_POST['ingredients']) ? $_POST['ingredients'] : [];

$recipes = []; 

if (!empty($selected_ingredients)) {
    
    $placeholders = implode(',', array_fill(0, count($selected_ingredients), '?'));

    // Prepare SQL query to fetch recipes
    $sql = "
        SELECT DISTINCT r.id, r.title, r.description, r.image_url, r.instructions
        FROM recipeAll r
        JOIN relationRecipeIng ri ON r.id = ri.recipe_id
        JOIN ingredient i ON ri.ingredient_id = i.ing_id
        WHERE i.ing_name IN ($placeholders)
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($selected_ingredients);
    $recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>


<html lang="en">
<head>
   
    <title>Generated Recipes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .navbar {
            width: 100%;
            height:30px;
            background-color: #ff5e62;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            font-size: 18px;
        }
        .navbar a:hover {
            background-color:rgb(250, 127, 129);
            border-radius: 5px;
        }
        .container {
            width: 80%;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: bold;
            color: black;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            background-color: #f9f9f9;
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        ul li h2 {
            font-size: 22px;
            font-weight: bold;
            margin: 0;
            color: black;
        }

        ul li p {
            font-size: 16px;
            color: #555;
            flex-grow: 1;
            margin-right: 20px;
        }

        ul li img {
            width: 250px;
            margin-right: 20px;
            border-radius: 5px;
        }

        .no-recipes {
            text-align: center;
            font-size: 18px;
            color: rgb(250, 127, 129);
            margin-top: 20px;
        }

        .ingredients {
            font-size: 16px;
            color: #444;
            background-color: #ffe6e7;
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
        }

        .ingredients ul {
            padding: 0;
            margin: 0;
        }

        .ingredients li {
            background: none;
            border: none;
            box-shadow: none;
            padding: 5px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #ffe6e7;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin-top: 10px;
        }

        form label {
            font-size: 16px;
            font-weight: bold;
            color: #ff5e62;
            margin-bottom: 5px;
        }

        form input {
            width: 80%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ff5e62;
            border-radius: 5px;
            text-align: center;
            outline: none;
        }

        form button {
            background-color: rgb(250, 127, 129);
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s;
            width: 100%;
        }

        form button:hover {
            background-color: #e6898b;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <a href="website.php">Explore Recipes</a>
    </div>

    <div class="container">
        <h1 class="header">Recipes You Can Make</h1>

        <?php if (!empty($recipes)): ?>
            <ul>
                <?php foreach ($recipes as $recipe): ?>
                    <li>
                        <div>
                            <h2><?php echo htmlspecialchars($recipe['title']); ?></h2>
                            <p><?php echo htmlspecialchars($recipe['description']); ?></p>
                            <p><?php echo htmlspecialchars($recipe['instructions']); ?></p>

                          
                            <div class="ingredients">
                                <strong>Ingredients:</strong>
                                <ul id="ingredients-list-<?php echo $recipe['id']; ?>">
                                    <?php
                                    $query = "SELECT q.quantity_value, q.quantity_unit, i.ing_name 
                                              FROM quantities q 
                                              JOIN ingredient i ON q.ingredient_id = i.ing_id 
                                              WHERE q.recipe_id = ?";
                                    $stmt = $pdo->prepare($query);
                                    $stmt->execute([$recipe['id']]);
                                    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach ($ingredients as $ingredient):
                                    ?>
                                        <li>➤ <?php echo $ingredient['quantity_value'] . " " . $ingredient['quantity_unit'] . " of " . $ingredient['ing_name']; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>

                        <div>
                            <img src="<?php echo htmlspecialchars($recipe['image_url']); ?>" alt="Recipe Image">

                            
                            <form class="adjust-recipe-form" data-recipe-id="<?php echo $recipe['id']; ?>">
                                <label for="servings">Number of People:</label>
                                <input type="number" name="servings" min="1" value="1" required>
                                <input type="hidden" name="recipe_id" value="<?php echo $recipe['id']; ?>">
                                <button type="submit">Adjust Recipe</button>
                            </form>

                           
                            <form method="POST" action="add_fav.php">
                                <input type="hidden" name="recipe_id" value="<?php echo $recipe['id']; ?>">
                                <button type="submit" class="add-to-favorites">Add to Favorites</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="no-recipes">No recipes found with the selected ingredients. Try selecting more ingredients!</p>
        <?php endif; ?>
    </div>

   
    <script>
    document.addEventListener("DOMContentLoaded", function () {
  
        document.querySelectorAll(".adjust-recipe-form").forEach(form => {
            form.addEventListener("submit", function (event) {
                event.preventDefault();
                
                const recipeId = this.querySelector('input[name="recipe_id"]').value;
                const servings = this.querySelector('input[name="servings"]').value;

                const formData = new FormData();
                formData.append('recipe_id', recipeId);
                formData.append('servings', servings);

                fetch('scale_recipe.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {

                    if (data.success) {
                        const ingredientsList = document.getElementById('ingredients-list-' + recipeId);
                        ingredientsList.innerHTML = '';

                        data.ingredients.forEach(item => {
                            const li = document.createElement('li');
                            li.textContent = `➤ ${item.quantity} ${item.unit} of ${item.ingredient}`;
                            ingredientsList.appendChild(li);
                        });
                    } else {
                        alert("Error updating ingredients.");
                    }
                })
                .catch(error => console.error("Error:", error));
            });
        });
    });
    </script>

</body>
</html>
