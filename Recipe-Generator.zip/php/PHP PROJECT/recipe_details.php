<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'dataBase_name');


if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $recipe_id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT * FROM recipeAll WHERE id = ?");
    $stmt->bind_param("i", $recipe_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $recipe = $result->fetch_assoc();
    } else {
        $recipe = null;
    }

    $stmt->close();
} else {
    echo "<script>alert('Invalid recipe ID.'); window.location.href='introduction.php';</script>";
    exit();
}
?>


<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recipe Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .navbar {
            width: 100%;
            height: 30px;
            background-color: #ff5e62;
            padding: 15px;
            display: flex;
            align-items: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            font-size: 18px;
        }

        .navbar a:hover {
            background-color: rgb(250, 127, 129);
            border-radius: 5px;
        }

        .container {
            width: 80%;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: bold;
            color: black;
        }

        .recipe-details {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
        }

        .recipe-details .text {
            flex: 1;
            padding-right: 20px;
        }

        .recipe-details .text h2 {
            font-size: 24px;
            font-weight: bold;
            color: #ff5e62;
        }

        .recipe-details .text p {
            font-size: 16px;
            color: #555;
        }

        .recipe-details .image {
            flex: 0 0 250px;
            text-align: center;
        }

        .recipe-details .image img {
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .ingredients {
            font-size: 16px;
            color: #444;
            background-color: #ffe6e7;
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
        }

        .ingredients ul {
            padding: 0;
            margin: 0;
        }

        .ingredients li {
            background: none;
            border: none;
            box-shadow: none;
            padding: 5px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #ffe6e7;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100%;
            margin-top: 10px;
        }

        form label {
            font-size: 16px;
            font-weight: bold;
            color: #ff5e62;
            margin-bottom: 5px;
        }

        form input {
            width: 80%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ff5e62;
            border-radius: 5px;
            text-align: center;
            outline: none;
        }

        form button {
            background-color: rgb(250, 127, 129);
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s;
            width: 100%;
        }

        form button:hover {
            background-color: #e6898b;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="website.php">Explore Recipes</a>
    <a href="favorites.php">Favorites</a>
</div>

<div class="container">
    <?php if ($recipe): ?>
        <h1 class="header"><?php echo htmlspecialchars($recipe['title']); ?></h1>

        <div class="recipe-details">
            <div class="text">
                <h2>Description</h2>
                <p><?php echo nl2br(htmlspecialchars($recipe['description'])); ?></p>

                <h2>Instructions</h2>
                <p><?php echo nl2br(htmlspecialchars($recipe['instructions'])); ?></p>

                <!-- Ingredients -->
                <div class="ingredients">
                    <strong>Ingredients:</strong>
                    <ul>
                        <?php
                        // Query ingredients based on recipe_id
                        $query = "SELECT q.quantity_value, q.quantity_unit, i.ing_name 
                                  FROM quantities q 
                                  JOIN ingredient i ON q.ingredient_id = i.ing_id 
                                  WHERE q.recipe_id = ?";
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("i", $recipe['id']);
                        $stmt->execute();
                        $ingredients_result = $stmt->get_result();

                        while ($ingredient = $ingredients_result->fetch_assoc()):
                        ?>
                            <li>➤ <?php echo htmlspecialchars($ingredient['quantity_value']) . " " . htmlspecialchars($ingredient['quantity_unit']) . " of " . htmlspecialchars($ingredient['ing_name']); ?></li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>

            <div class="image">
                <?php if (!empty($recipe['image_url'])): ?>
                    <img src="<?php echo htmlspecialchars($recipe['image_url']); ?>" alt="Recipe Image">
                <?php else: ?>
                    <p>No image available</p>
                <?php endif; ?>
            </div>
        </div>

       
    <?php else: ?>
        <p>Recipe not found.</p>
    <?php endif; ?>
</div>

</body>
</html>
