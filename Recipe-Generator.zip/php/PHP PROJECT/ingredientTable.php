<html>
    <body>

<?php

include("selectdb.php");


$query= 'CREATE TABLE ingredient (
    ing_id INT AUTO_INCREMENT PRIMARY KEY,
    ing_name VARCHAR(255) NOT NULL
)';


if (@mysqli_query($dbc, $query)) {
    print '<p>The ingredient table has been created successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>

</body>
</html>