<?php
include("selectdb.php");


$query = 'INSERT INTO relationRecipeIng (recipe_id, ingredient_id)
VALUES (1, 14),    
       (1, 7),
       (1, 6),

       (2, 3),
       (2, 4),
       (2, 12),
       (2, 13),
       (2, 26),
       (2, 28),
       (2, 28),
       (2, 29),
       (2, 30),

       (3, 3),
        (3, 4,),
        (3, 5),
        (3, 6),
        (3, 7),
        (3, 8),
        (3, 10),
        (3, 14),
        (3, 19),
        (3, 20),
        (3, 21),
        (3, 22)



       ';



if (@mysqli_query($dbc, $query)) {
    print '<p>The informtions have been inserted successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>