<?php
include("selectDb.php");

$username = 'admin'; 
$password = '000'; 


$hashed_password = password_hash($password, PASSWORD_DEFAULT);


$query = "INSERT INTO login (username, password, role) VALUES (?, ?, 'admin')";

$stmt = $dbc->prepare($query);
$stmt->bind_param("ss", $username, $hashed_password);

if ($stmt->execute()) {
    echo '<p>Admin has been added successfully to the login table.</p>';
} else {
    echo '<p>Error: ' . $stmt->error . '</p>';
}

$stmt->close();
mysqli_close($dbc);
?>
