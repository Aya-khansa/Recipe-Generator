<html>
    <body>

<?php

include("selectdb.php");


$query= 'CREATE TABLE relationRecipeIng (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id INT, 
    ingredient_id INT, 
    FOREIGN KEY (recipe_id) REFERENCES recipeAll(id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredient(ing_id) ON DELETE CASCADE
)';


if (@mysqli_query($dbc, $query)) {
    print '<p>The recipe table has been created successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>

</body>
</html>