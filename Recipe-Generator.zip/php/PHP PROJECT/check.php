<?php
session_start(); 
$conn = @mysqli_connect('localhost', 'root', '', 'loginDb') or die("Connection error");
@mysqli_select_db($conn, 'dataBase_name') or die("Error to database connection");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);  

    $stmt = $conn->prepare("SELECT id, password, role FROM login WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {  
        $stmt->bind_result($user_id, $hashed_password, $role);
        $stmt->fetch();

 
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id; 

           
            if ($role == 'admin') {
                $_SESSION['role'] = 'admin'; 
                header("Location: admin_dashboard.php"); 
            } else {
                $_SESSION['role'] = 'user'; 
                header("Location: website.php"); 
            }
            exit();
        } else {
            echo "<script>alert('Incorrect username or password!'); window.location='forms.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('Incorrect username or password!'); window.location='forms.php';</script>";
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>

