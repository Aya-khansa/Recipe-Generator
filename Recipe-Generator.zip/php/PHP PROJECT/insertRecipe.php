<?php
include("selectdb.php");


$query = 'INSERT INTO recipeAll(title, description, instructions, image_url)
VALUES ("Tomato Soup", 
        "A delicious tomato-based soup", 
        "1.Add garlic. 2. Add tomatoes and cook..", 
        "tomato_soup.jpg"),
        
        ("Oats", 
        "A delicious breakfast or snack", 
        "1. Add oats. 2.Add milk.", 
        "Oats.jpg"),

        ("Pizza", 
        "A delicious pizza", 
        "1. Add tomato sauce", 
        "pizza.jpg");
';




if (@mysqli_query($dbc, $query)) {
    print '<p>The informtions have been inserted successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>