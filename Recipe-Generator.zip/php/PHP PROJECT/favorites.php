<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'dataBase_name');

// Check database connection
if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view favorites.'); window.location.href='login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id']; // Directly use user_id from session

// Fetch only the logged-in user's favorite recipes
$stmt = $conn->prepare("
    SELECT recipeAll.* FROM recipeAll 
    INNER JOIN favoriteAll ON recipeAll.id = favoriteAll.recipe_id 
    WHERE favoriteAll.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$favorites = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Favorite Recipes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
            text-align: center;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #ff5e62;
            text-align: center;
        }

        .recipe-card {
            background-color: #fff;
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .recipe-details {
            text-align: left;
            flex-grow: 1;
            padding-right: 20px;
        }

        .recipe-card h3 {
            color: black;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .recipe-card p {
            color: #555;
            margin-bottom: 5px;
        }

        .recipe-card img {
            width: 120px;
            height: auto;
            border-radius: 5px;
            object-fit: cover;
        }

        .buttons-container {
            display: flex;
            gap: 10px; /* Adds space between the buttons */
        }

        .remove-button, .view-details-button {
            background-color: #ff5e62;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 14px;
        }

        .remove-button:hover, .view-details-button:hover {
            background-color: #e6484f;
        }

        .no-favorites {
            font-size: 18px;
            color: #777;
            margin-top: 20px;
        }

        .design {
            width: 100%;
            height: 20px;
            background-color: #ff5e62;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .design a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            font-size: 18px;
        }

        .design a:hover {
            background-color: rgb(250, 127, 129);
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="design">
        <a href="website.php">Explore Recipes</a>
    </div>
</div>

<div class="container">
    <h2>Your Favorite Recipes</h2>

    <?php if ($favorites): ?>
        <?php foreach ($favorites as $recipe): ?>
            <div class="recipe-card">
                <div class="recipe-details">
                    <h3><?php echo htmlspecialchars($recipe['title']); ?></h3>
                    <p><?php echo htmlspecialchars($recipe['description']); ?></p>
                    <div class="buttons-container">
                        <form action="remove_favorite.php" method="POST">
                            <input type="hidden" name="recipe_id" value="<?php echo $recipe['id']; ?>">
                            <button type="submit" class="remove-button">Remove from Favorites</button>
                        </form>
                        <a href="recipe_details.php?id=<?php echo $recipe['id']; ?>" class="view-details-button">View Recipe Details</a>
                    </div>
                </div>
                <?php if (!empty($recipe['image_url'])): ?>
                    <img src="<?php echo htmlspecialchars($recipe['image_url']); ?>" alt="Recipe Image">
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="no-favorites">You haven't added any favorite recipes yet.</p>
    <?php endif; ?>
</div>

</body>
</html>
