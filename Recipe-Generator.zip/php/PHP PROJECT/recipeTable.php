<html>
    <body>

<?php

include("selectdb.php");


$query= 'CREATE TABLE recipeAll (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    instructions TEXT NOT NULL,
    image_url VARCHAR(255))';


if (@mysqli_query($dbc, $query)) {
    print '<p>The recipe table has been created successfully.</p>';
} 
else {
    print '<p>Error: Could not create the table. ' . mysqli_error($dbc) . '</p>';
}


mysqli_close($dbc);
?>

</body>
</html>