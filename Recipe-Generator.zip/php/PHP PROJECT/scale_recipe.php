<?php
// scale_recipe.php

$host = 'localhost';
$db = 'dataBase_name';
$user = 'root'; 
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$recipe_id = $_POST['recipe_id'];
$servings = $_POST['servings'];


$query = "SELECT q.quantity_value, q.quantity_unit, i.ing_name 
          FROM quantities q 
          JOIN ingredient i ON q.ingredient_id = i.ing_id 
          WHERE q.recipe_id = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$recipe_id]);
$ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);


$adjusted_ingredients = [];
foreach ($ingredients as $ingredient) {
    $scaled_quantity = $ingredient['quantity_value'] * $servings;
    $adjusted_ingredients[] = [
        'quantity' => $scaled_quantity,
        'unit' => $ingredient['quantity_unit'],
        'ingredient' => $ingredient['ing_name']
    ];
}


echo json_encode(['success' => true, 'ingredients' => $adjusted_ingredients]);
?>