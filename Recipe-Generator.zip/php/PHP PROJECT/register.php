<?php 
session_start();

$conn = mysqli_connect('localhost', 'root', '', 'dataBase_name');


if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['usernameAcc']);
    $password = trim($_POST['passwordAcc']);

  
    $stmt = $conn->prepare("SELECT id FROM login WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('Username already exists! Please choose another one.'); window.location='createAcc.php';</script>";
        exit();
    }
    $stmt->close();

 
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);


    $stmt = $conn->prepare("INSERT INTO login (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $conn->insert_id; // Get the last inserted ID

  
        error_log("Session set: User ID = " . $_SESSION['user_id']);

     
        header("Location: forms.php");
        exit();
    } else {
        echo "<script>alert('Error registering user. Please try again.'); window.location='createAcc.php';</script>";
    }

    $stmt->close();
}
?>
