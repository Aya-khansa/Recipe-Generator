<html>
    <body>

<?php
$dbname = "dataBase_name";
$dbc = @mysqli_connect('localhost', 'root', '');


if ($dbc) {
    print '<p>Successfully connected  to the database server.</p>';


    $query = "CREATE DATABASE $dbname";

    if (@mysqli_query($dbc, $query)) {
        print "<p>The database '$dbname' has been created successfully.</p>";
    } else {
        print "<p>The database '$dbname' could not be created: " . mysqli_error($dbc) . "</p>";
    }

 
    mysqli_close($dbc);
} else {
    print "<p>Could not connect to the MySQL server: " . mysqli_connect_error() . "</p>";
}
?>

</body>
</html>