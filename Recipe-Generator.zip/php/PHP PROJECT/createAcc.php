<?php session_start(); ?>

<html lang="en">
<head>
    
    <title>Create Account</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; 
            gap: 40px; 
            background-color: #f8f8f8;
        }

        .image-box {
            width: 500px;
            height: 500px;
            background-image: url("php project.jpg");
            background-size: cover;
            background-position: center;
            border-radius: 10px;
        }

        .form-box {
            width: 300px;
            padding: 30px;
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            text-align: center;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .form-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-box button {
            width: 100%;
            padding: 10px;
            background: #ff5e62;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .form-box button:hover {
            background: #ff3b3f;
        }

        .login-link {
            margin-top: 15px;
            font-size: 14px;
        }

        .login-link a {
            color: #ff5e62;
            text-decoration: none;
            font-weight: bold;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="image-box"></div>

        <div class="form-box">
            <h2>Create Account</h2>

           
            <?php if (isset($_SESSION['error'])): ?>
                <p class="error-message"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
            <?php endif; ?>

            <form method="post" action="register.php">
                <input type="text" name="usernameAcc" placeholder="Username" required>
                <input type="password" name="passwordAcc" placeholder="Password" required>
                <button type="submit">Sign Up</button>
            </form>

            <p class="login-link">Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>

</body>
</html>
